<h1>404</h1>
<p>
<img src="http://dev.iintoo.com/images/empty-page.jpg">
</p>
